Made by Sumin Park as part of 

React basics course in coursera.

node_modules folder was intentionally left out to reduce file size.